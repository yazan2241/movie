import './bootstrap';
import './project';
import './all.min';
